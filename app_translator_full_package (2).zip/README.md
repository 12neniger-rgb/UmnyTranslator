# App Translator — Prototype (Electron + OCR + Translate)

This package contains:
- An Electron prototype that takes a screenshot, runs OCR (tesseract.js) and translates using LibreTranslate.
- A Python demo script that performs OCR (pytesseract) on an image and translates using LibreTranslate.

## Electron prototype
Files: main.js, preload.js, index.html, renderer.js, package.json

Quick start:
1. Install Node and npm.
2. Run `npm install`.
3. Run `npm start`.

Notes:
- tesseract.js uses WASM and usually works without a separate Tesseract install, but you can install system tesseract for better results.
- Replace `translateApiUrl`/`translateApiKey` in renderer.js or main.js if you want to use Google/DeepL.

## Python demo (ocr_translate.py)
Requirements:
- Python 3.8+
- pip install pillow pytesseract requests

Usage:
- For best results, install Tesseract OCR on your system (so pytesseract can call it).
- Run: `python ocr_translate.py input_image.png ru`
- The script prints OCR text and the translation to stdout.

LibreTranslate is used as an example. You can change the API URL in the script.
