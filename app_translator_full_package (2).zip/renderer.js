const go = document.getElementById('go');
const ocrEl = document.getElementById('ocr');
const trEl = document.getElementById('tr');

go.addEventListener('click', async () => {
  go.disabled = true; go.textContent = 'Работаю...';
  const lang = document.getElementById('lang').value || 'ru';
  const result = await window.electronAPI.takeScreenshotAndTranslate({ targetLang: lang, translateApiUrl: 'https://libretranslate.com/translate' });
  if (result.ok) {
    ocrEl.textContent = result.text;
    trEl.textContent = result.translated;
  } else {
    ocrEl.textContent = 'Ошибка: ' + result.error;
  }
  go.disabled = false; go.textContent = 'Сделать скрин и перевести';
});
