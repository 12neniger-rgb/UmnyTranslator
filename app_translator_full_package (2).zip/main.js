const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const screenshot = require('screenshot-desktop');
const Tesseract = require('tesseract.js');
const fetch = require('node-fetch');
const fs = require('fs');

function createWindow() {
  const win = new BrowserWindow({
    width: 900,
    height: 700,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js')
    }
  });
  win.loadFile('index.html');
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('take-and-translate', async (event, opts) => {
  try {
    const imgPath = path.join(app.getPath('userData'), 'shot.png');
    await screenshot({ filename: imgPath });
    const { data: { text } } = await Tesseract.recognize(imgPath, 'eng+rus');
    const translated = await translateText(text, opts.targetLang, opts.translateApiUrl, opts.translateApiKey);
    return { ok: true, text, translated };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

async function translateText(text, targetLang, apiUrl = 'https://libretranslate.com/translate', apiKey = null) {
  const body = {
    q: text,
    source: 'auto',
    target: targetLang,
    format: 'text'
  };
  if (apiKey) body.api_key = apiKey;
  const res = await fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(`Translate API error: ${res.status}`);
  const j = await res.json();
  return j.translatedText || j.result || j;
}
