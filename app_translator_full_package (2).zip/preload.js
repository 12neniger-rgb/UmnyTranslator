const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  takeScreenshotAndTranslate: (opts) => ipcRenderer.invoke('take-and-translate', opts)
});
