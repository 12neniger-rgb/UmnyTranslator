# ocr_translate.py
# Simple demo: OCR an image and translate the text using LibreTranslate
# Requirements:
#   pip install pillow pytesseract requests
# And install system tesseract (recommended) so pytesseract works:
#   - Ubuntu: sudo apt install tesseract-ocr
#   - Windows: download installer from https://github.com/tesseract-ocr/tesseract
#
# Usage:
#   python ocr_translate.py input.png ru

import sys
from PIL import Image
import pytesseract
import requests

def translate_text(text, target='ru', api_url='https://libretranslate.com/translate', api_key=None):
    payload = {
        'q': text,
        'source': 'auto',
        'target': target,
        'format': 'text'
    }
    if api_key:
        payload['api_key'] = api_key
    resp = requests.post(api_url, json=payload, timeout=15)
    resp.raise_for_status()
    data = resp.json()
    return data.get('translatedText') or data.get('result') or data

def main():
    if len(sys.argv) < 3:
        print('Usage: python ocr_translate.py input_image.png target_lang')
        sys.exit(1)
    img_path = sys.argv[1]
    target = sys.argv[2]
    img = Image.open(img_path)
    text = pytesseract.image_to_string(img, lang='eng+rus')
    print('--- OCR TEXT ---')
    print(text)
    print('--- TRANSLATION ---')
    try:
        tr = translate_text(text, target=target)
        print(tr)
    except Exception as e:
        print('Translate error:', e)

if __name__ == '__main__':
    main()
